/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author cyril
 */
public class Typeconteneur {
    private String contType;
    private String typeLibel;
    
    private final ArrayList<Typeconteneur> lesEnrg= new ArrayList<>();
    private static Connection laConnexion= 
            ControleConnexion.getLaConnexionStatique();

    public String getContType() {
        return contType;
    }

    public String getTypeLibel() {
        return typeLibel;
    }

    public ArrayList<Typeconteneur> getLesEnrg() {
        return lesEnrg;
    }

    public void setContType(String contType) {
        this.contType = contType;
    }

    public void setTypeLibel(String typeLibel) {
        this.typeLibel = typeLibel;
    }

    public Typeconteneur(){
        lireRecup();
    }
    
    public Typeconteneur(String contType, String typeLibel){
        this.contType=contType;
        this.typeLibel=typeLibel;
    }
    
    private void lireRecup (){
        
        
        String reqSQL="SELECT * FROM typeconteneur";
        lesEnrg.retainAll(lesEnrg);
        try {
            //permet d'alimenter le jeu d'enregistrement
            Statement state= laConnexion.createStatement();
            ResultSet rs=state.executeQuery(reqSQL);
                while (rs.next()){
                   String uncontType = rs.getString("contType");   
                   String untypeLibel = rs.getString("typeLibel");
                   lesEnrg.add(new Typeconteneur(uncontType, untypeLibel));
                }
            }
         catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Problème rencontré : "
                    + ex.getMessage(),"Message", JOptionPane.ERROR_MESSAGE);
        }
    }
}
