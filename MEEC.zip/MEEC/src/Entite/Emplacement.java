/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Flo
 */
public class Emplacement 
{
    private String numEmp;
    private String numAllee;
    private String numQuai;
    private final ArrayList<Emplacement> lesEnrg = new ArrayList<>();
    private static Connection laConnexion = ControleConnexion.getLaConnexionStatique();

    public String getNumEmp() {
        return numEmp;
    }

    public String getNumAllee() {
        return numAllee;
    }

    public String getNumQuai() {
        return numQuai;
    }

    public ArrayList<Emplacement> getLesEnrg() {
        return lesEnrg;
    }

    public void setNumEmp(String numEmp) {
        this.numEmp = numEmp;
    }

    public void setNumAllee(String numAllee) {
        this.numAllee = numAllee;
    }

    public void setNumQuai(String numQuai) {
        this.numQuai = numQuai;
    }

    public Emplacement() {
    }
    
    public Emplacement(String numEmp, String numAllee, String numQuai) 
    {
        this.numEmp = numEmp;
        this.numAllee = numAllee;
        this.numQuai = numQuai;
    }
    
    public Emplacement(String NumAllee, String NumQuai) 
    {
        lireRecup("", NumAllee, NumQuai);
    }
    
    private void lireRecup(String unNumEmp, String unNumAllee, String unNumQuai)
    {
        // CRUD
        // Create
        // Read
        // Update
        // Delete
        
        // Lire les données de la BDD
        
        if(unNumEmp.equals(""))
        {
            unNumEmp = "%";
        }
        
        if(unNumAllee.equals(""))
        {
            unNumAllee = "%";
        }
        
        if(unNumQuai.equals(""))
        {
            unNumQuai = "%";
        }
        
        String reqSQL = "SELECT * FROM emplacement WHERE numEmp LIKE '" + unNumEmp + "' AND numAllee LIKE '" + unNumAllee + "' AND numQuai LIKE '" + unNumQuai + "'";
        
        lesEnrg.retainAll(lesEnrg);  // Vider les enregistrements.
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            while(rs.next())
            {
                String leNumEmp = rs.getString("numEmp");
                String leNumAllee = rs.getString("numAllee");
                String leNumQuai = rs.getString("numQuai");
                lesEnrg.add(new Emplacement(leNumEmp, leNumAllee, leNumQuai));
            }
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public boolean creer(String unNumEmp, String unNumAllee, String unNumQuai)
    {
        boolean bcreer = false;
        String reqSQL = "SELECT COUNT(*) AS nb FROM emplacement WHERE numEmp = '" + unNumEmp + "' AND numAllee = '" + unNumAllee + "' AND numQuai = '" + unNumQuai + "'";
        
        Position uneposition = new Position();
        
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            rs.next();
            //JOptionPane.showMessageDialog(null, rs.getInt("nb"));
            
            if(rs.getInt("nb") == 0)
            {
                String reqSQLA = "INSERT INTO emplacement VALUES(?, ?, ?)";
                PreparedStatement prepare = laConnexion.prepareStatement(reqSQLA);
                prepare.setString(1, unNumEmp);
                prepare.setString(2, unNumAllee);
                prepare.setString(3, unNumQuai);
                prepare.execute();
                prepare.close();
                bcreer = true;
                int i;
                for(i=0; i<=3;i++){
                    uneposition.creer(unNumEmp,unNumAllee, unNumQuai, String.valueOf(i));
                }
                bcreer = true;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Le numéro d'emplacement existe déjà.", "ERREUR", JOptionPane.ERROR_MESSAGE);
            }
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
        
        return bcreer;
    }
    
    public boolean modifier(String unNumEmp, String unNumAllee, String unNumQuai, String nouveauNumEmp)
    {
        boolean bmodif = false;
        String reqSQL = "SELECT COUNT(*) AS nb FROM emplacement WHERE numEmp = '" + nouveauNumEmp + "' AND numAllee = '" + unNumAllee + "' AND numQuai = '" + unNumQuai + "'";
        
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            rs.next();
            
            if(rs.getInt("nb") == 0)
            {
                String reqSQLD = "UPDATE emplacement SET numEmp = ? WHERE numEmp = ? AND numAllee = ? AND numQuai = ?";
                PreparedStatement prepare = laConnexion.prepareStatement(reqSQLD);
                prepare.setString(1, nouveauNumEmp);
                prepare.setString(2, unNumEmp);
                prepare.setString(3, unNumAllee);
                prepare.setString(4, unNumQuai);
                prepare.execute();
                prepare.close();
                bmodif = true;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Un autre emplacement porte déjà le même numéro.", "ERREUR", JOptionPane.ERROR_MESSAGE);
            }
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
        return bmodif;
    }
    
       
    public boolean supprimer(String unNumEmp, String unNumAllee, String unNumQuai)
    {
        boolean bsupp = false;
      //  String reqSQL = "SELECT COUNT(*) AS nb FROM emplacement WHERE numEmp = '" + unNumEmp + "' AND numAllee = '" + unNumAllee + "' AND numQuai = '" + unNumQuai + "'";
        Position unePos = new Position(unNumEmp, unNumAllee, unNumQuai, false);
        
        
        if(unePos.getLesEnrg().isEmpty())
        {
            try {
             //   Statement state = laConnexion.createStatement();
             //   ResultSet rs = state.executeQuery(reqSQL);


                    String reqSQLD = "DELETE FROM emplacement WHERE numEmp = ? AND numAllee = ? AND numQuai = ?";
                    PreparedStatement prepare = laConnexion.prepareStatement(reqSQLD);
                    prepare.setString(1, unNumEmp);
                    prepare.setString(2, unNumAllee);
                    prepare.setString(3, unNumQuai);
                    prepare.execute();
                    prepare.close();
                    bsupp = true;
                    
                    unePos.supprimer(unNumEmp, unNumAllee, unNumQuai);


            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
                bsupp = false;
            }
        }else{
            
            //unePos.getLesEnrg().get(0).supprimer(unePos.getNumPos());
            
            JOptionPane.showMessageDialog(null, "Impossible de supprimer un emplacement possedant un conteneur  ", "MESSAGE", JOptionPane.ERROR_MESSAGE);
            bsupp = false;
        
        }
        return bsupp;
    }
}

    /*
    public boolean supprimer(String unNumEmp, String unNumAllee, String unNumQuai)
    {
        boolean bsupp = false;
   //     String reqSQL = "SELECT COUNT(*) AS nb FROM emplacement WHERE numEmp = '" + unNumEmp + "' AND numAllee = '" + unNumAllee + "' AND numQuai = '" + unNumQuai + "'";
        
        try {
            
          //  Statement state = laConnexion.createStatement();
          //  ResultSet rs = state.executeQuery(reqSQL);
            
            Position unePos = new Position(unNumEmp, unNumAllee, unNumQuai,false);
            int i;
         //   rs.next();
            if (unePos.getLesEnrg().size()==0)
            {
                unePos = new Position(unNumEmp, unNumAllee, unNumQuai,true);
                unePos.getLesEnrg().get(0).supprimer(unNumEmp,unNumAllee,unNumQuai);
                String reqSQLD = "DELETE FROM emplacement WHERE numEmp = ? AND numAllee = ? AND numQuai = ?";
                PreparedStatement prepare = laConnexion.prepareStatement(reqSQLD);
                prepare.setString(1, unNumEmp);
                prepare.setString(2, unNumAllee);
                prepare.setString(3, unNumQuai);
                prepare.execute();
                prepare.close();
                bsupp = true;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "L'emplacement spécifié comporte des conteneurs", "ERREUR", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
        
        return bsupp;
    }
}*/
