/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Flo
 */
public class Allee {
    
    private String numAllee;
    private String numQuai;
    private final ArrayList<Allee> lesEnrg = new ArrayList<>();
    private static Connection laConnexion = ControleConnexion.getLaConnexionStatique();

    public String getNumAllee() {
        return numAllee;
    }
    
    public String getNumQuai() {
        return numQuai;
    }

    public ArrayList<Allee> getLesEnrg() {
        return lesEnrg;
    }

    public void setNumAllee(String numAllee) {
        this.numAllee = numAllee;
    }
    
    public Allee(String numAllee, String numQuai) {
        this.numAllee = numAllee;
        this.numQuai = numQuai;
    }
    
    public Allee(String NumQuai) {
        lireRecup("", NumQuai);
    }
    
    private void lireRecup(String unNumAllee, String unNumQuai)
    {
        // CRUD
        // Create
        // Read
        // Update
        // Delete
        
        // Lire les données de la BDD
        
        if(unNumAllee.equals(""))
        {
            unNumAllee = "%";
        }
        
        if(unNumQuai.equals(""))
        {
            unNumQuai = "%";
        }
        
        String reqSQL = "SELECT * FROM allee WHERE numAllee LIKE '" + unNumAllee + "' AND numQuai LIKE '" + unNumQuai + "'";
        
        lesEnrg.retainAll(lesEnrg);  // Vider les enregistrements.
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            while(rs.next())
            {
                String leNumAllee = rs.getString("numAllee");
                String leNumQuai = rs.getString("numQuai");
                lesEnrg.add(new Allee(leNumAllee, leNumQuai));
            }
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public boolean creer(String unNumAllee, String unNumQuai)
    {
        boolean bcreer = false;
        String reqSQL = "SELECT COUNT(*) AS nb FROM allee WHERE numAllee = '" + unNumAllee + "' AND numQuai = '" + unNumQuai + "'";
        
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            rs.next();
            //JOptionPane.showMessageDialog(null, rs.getInt("nb"));
            
            if(rs.getInt("nb") == 0)
            {
                String reqSQLA = "INSERT INTO allee VALUES(?,?)";
                PreparedStatement prepare = laConnexion.prepareStatement(reqSQLA);
                prepare.setString(1, unNumAllee);
                prepare.setString(2, unNumQuai);
                prepare.execute();
                prepare.close();
                bcreer = true;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Le numéro d'allée existe déjà.", "ERREUR", JOptionPane.ERROR_MESSAGE);
            }
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
        
        return bcreer;
    }
    
    public boolean modifier(String unNumAllee, String unNumQuai, String nouveauNumAllee)
    {
        boolean bmodif = false;
        String reqSQL = "SELECT COUNT(*) AS nb FROM allee WHERE numAllee = '" + nouveauNumAllee + "' AND numQuai = '" + unNumQuai + "'";
        
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            rs.next();
            
            if(rs.getInt("nb") == 0)
            {
                String reqSQLD = "UPDATE allee SET numAllee = ? WHERE numAllee = ? AND numQuai = ?";
                PreparedStatement prepare = laConnexion.prepareStatement(reqSQLD);
                prepare.setString(1, nouveauNumAllee);
                prepare.setString(2, unNumAllee);
                prepare.setString(3, unNumQuai);
                prepare.execute();
                prepare.close();
                bmodif = true;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Une autre allée porte déjà le même numéro.", "ERREUR", JOptionPane.ERROR_MESSAGE);
            }
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
        return bmodif;
    }
    
    public boolean supprimer(String unNumAllee, String unNumQuai)
    {
        boolean bsupp = false;
        String reqSQL = "SELECT COUNT(*) AS nb FROM allee WHERE numAllee = '" + unNumAllee + "' AND numQuai = '" + unNumQuai + "'";
        
        try {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            rs.next();
            if(rs.getInt("nb") != 0)
            {
                String reqSQLD = "DELETE FROM allee WHERE numAllee = ? AND numQuai = ?";
                PreparedStatement prepare = laConnexion.prepareStatement(reqSQLD);
                prepare.setString(1, unNumAllee);
                prepare.setString(2, unNumQuai);
                prepare.execute();
                prepare.close();
                bsupp = true;
            }
            else
            {
                JOptionPane.showMessageDialog(null, "L'allée spécifiée est introuvable", "ERREUR", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
        
        return bsupp;
    }
}
