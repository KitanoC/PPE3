/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Cyril
 */
public class XmlFile {
    
    private String XMLFilePath;
    private static Connection laConnexion = ControleConnexion.getLaConnexionStatique();
    
    
    public XmlFile()
    {
        // Constructeur de base
    }
    
    public XmlFile(ArrayList<String> liste, String nomBateau)
    {
        // Ecriture du fichier
        
        XMLFilePath = System.getProperty("user.home") + "/Desktop/" + nomBateau + "_" + LocalDateTime.now().toString().substring(0, 10) + ".xml";
        int i = 0;
        
        try
        {
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document document = documentBuilder.newDocument();
            
            document.setXmlStandalone(false);
            
            // racine (docker)
            Element docker = document.createElement("docker");
            document.appendChild(docker);
            
            // Attribut "date" du docker
            Attr date = document.createAttribute("date");
            date.setValue(LocalDateTime.now().toString().substring(0, 10));
            docker.setAttributeNode(date);
 
            // Ajout de l'élément "Bateau"
            Element bateau = document.createElement("bateau");
            docker.appendChild(bateau);
            
            // Attribut "Nom" du bateau
            Attr nomBat = document.createAttribute("nom");
            nomBat.setValue(nomBateau);
            bateau.setAttributeNode(nomBat);
            
            for(i = 0; i < liste.size(); i++)
            {
                
                LeConteneur unConteneur = new LeConteneur(liste.get(i));
                
                String codePosition = unConteneur.getLesEnrg().get(0).getCodePosition();
                
                String numQuai = codePosition.substring(0, 3);
                String numAllee = codePosition.substring(3, 6);
                String numEmplacement = codePosition.substring(6, 9);
                String numEtage = codePosition.substring(9);
                String numCli = " ";
                
                
                // Ajout de l'élément "Conteneur"
                Element conteneur = document.createElement("conteneur");
                bateau.appendChild(conteneur);
                
                // Ajout de l'élément "Numero"
                Element numero = document.createElement("numero");
                numero.appendChild(document.createTextNode(liste.get(i)));
                conteneur.appendChild(numero);

                // Ajout de l'élément "Quai"
                Element quai = document.createElement("quai");
                quai.appendChild(document.createTextNode(numQuai));
                conteneur.appendChild(quai);

                // Ajout de l'élément "Allée"
                Element allee = document.createElement("allee");
                allee.appendChild(document.createTextNode(numAllee));
                conteneur.appendChild(allee);

                // Ajout de l'élément "Emplacement"
                Element emplacement = document.createElement("emplacement");
                emplacement.appendChild(document.createTextNode(numEmplacement));
                conteneur.appendChild(emplacement);
                
                // Ajout de l'élément "Etage"
                Element etage = document.createElement("etage");
                etage.appendChild(document.createTextNode(numEtage));
                conteneur.appendChild(etage);
                
                // Ajout de l'élément "Type"
                Element type = document.createElement("type");
                type.appendChild(document.createTextNode(unConteneur.getLesEnrg().get(0).getContCode()));
                conteneur.appendChild(type);
                
                if(unConteneur.getLesEnrg().get(0).getNumCli() != null)
                {
                    //
                    
                    numCli = unConteneur.getLesEnrg().get(0).getNumCli();
                }
                
                Element client = document.createElement("client");
                client.appendChild(document.createTextNode(numCli));
                conteneur.appendChild(client);
            }
            
            

            // Création du XML
            // Transforme l'objet DOM en XML
            
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
            transformer.setOutputProperty(OutputKeys.STANDALONE, "no");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(new File(XMLFilePath));
 
            transformer.transform(domSource, streamResult);
 
            JOptionPane.showMessageDialog(null, "Fichier exporté", "INFO", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerException ex) {
            Logger.getLogger(XmlFile.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
    }
    
    public XmlFile(String path)
    {
        // Lecture du fichier
        try{
            final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            try{
                final DocumentBuilder builder = factory.newDocumentBuilder();
                final Document document = builder.parse(new File(path));

                //Recuperation de la racine 
                final Element racine = document.getDocumentElement();
                System.out.println(racine.getNodeName());

                //Recuperation des bateaux 
                final NodeList racineNoeuds = racine.getElementsByTagName("Nom");
                final int nbRacineNoeuds = racineNoeuds.getLength();

                //System.out.println(nbRacineNoeuds);

                for (int i = 0; i<nbRacineNoeuds; i++)
                {   
                    if (racineNoeuds.item(i).getNodeType() == Node.ELEMENT_NODE) {
                        //Recupere le nom du bateau
                        final Element Bateaux = (Element) racineNoeuds.item(i);
                        System.out.println("Nom: " + Bateaux.getAttribute("Nom"));

                        // Recupere les conteneurs dans le bateau
                        final NodeList Nom = (NodeList) Bateaux.getElementsByTagName("Conteneur") ;
                        final int nbConteneur = Nom.getLength();

                            //System.out.println(nbConteneur);
                            for (int j = 0; j < nbConteneur; j++) {


                           System.out.println("Conteneur: ");

                            // Recupere les éléments du container
                            final Element numero = (Element) Bateaux.getElementsByTagName("numero").item(j);
                            final Element quai = (Element) Bateaux.getElementsByTagName("quai").item(j);
                            final Element allee = (Element) Bateaux.getElementsByTagName("allee").item(j);
                            final Element emplacement = (Element) Bateaux.getElementsByTagName("emplacement").item(j);
                            final Element etage = (Element) Bateaux.getElementsByTagName("etage").item(j);
                            final Element code = (Element) Bateaux.getElementsByTagName("code").item(j);
                            final Element client = (Element) Bateaux.getElementsByTagName("client").item(j);

                            //Affiche les éléments du conteneur
                            System.out.println("    Numero: " + numero.getTextContent());
                            System.out.println("    Quai: " + quai.getTextContent());
                            System.out.println("    Allee: " + allee.getTextContent());
                            System.out.println("    Emplacement: " + emplacement.getTextContent());
                            System.out.println("    Etage: " + etage.getTextContent());
                            System.out.println("    Code: " + code.getTextContent());
                            System.out.println("    Client: " + client.getTextContent());

                            String num = numero.getTextContent() ;
                            String qquai = quai.getTextContent();
                            String aallee = allee.getTextContent();
                            String eemplacement = emplacement.getTextContent();
                            String eetage = etage.getTextContent();
                            String ccode = code.getTextContent();
                            String cclient = client.getTextContent();
                            Integer ccclient = null;
                            String pposition = qquai + aallee + eemplacement + eetage;


                            Date date=Calendar.getInstance().getTime();
                            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                            String strDate = dateFormat.format(date);



                            Statement state = laConnexion.createStatement();

                            if (!cclient.equals("")) {

                            ccclient = Integer.valueOf(cclient);
                            String reqSQL = " INSERT INTO leconteneur VALUES (?,?,?,?,?)";
                            PreparedStatement prepare = laConnexion.prepareStatement(reqSQL);
                            prepare.setString(1, num);
                            prepare.setInt(2, ccclient);
                            prepare.setString(3, strDate);
                            prepare.setString(4, ccode);
                            prepare.setString(5, pposition);
                            prepare.execute();
                            prepare.close();
                            }else{

                            String reqSQL = " INSERT INTO leconteneur VALUES (?,?,?,?,?)";
                            PreparedStatement prepare = laConnexion.prepareStatement(reqSQL);
                            prepare.setString(1, num);
                            prepare.setNull(2, java.sql.Types.INTEGER);
                            prepare.setString(3, strDate);
                            prepare.setString(4, ccode);
                            prepare.setString(5, pposition);
                            prepare.execute();
                            prepare.close();
                            }

                            Position laPosition = new Position(eemplacement, aallee, qquai, eetage, true); 
                            laPosition.miseAjour(pposition, num);


                            JOptionPane.showMessageDialog(null, "Fichier importé", "INFO", JOptionPane.INFORMATION_MESSAGE);

                            }
                        }
                    }

            }catch (final ParserConfigurationException e){
                e.printStackTrace();
                //JOptionPane.showMessageDialog(null, e.getMessage(), "ERREUR", JOptionPane.ERROR_MESSAGE);
            }
            catch (final SAXException e){
                e.printStackTrace();
                //JOptionPane.showMessageDialog(null, e.getMessage(), "ERREUR", JOptionPane.ERROR_MESSAGE);
            }
            catch (final IOException e){
                e.printStackTrace();
                //JOptionPane.showMessageDialog(null, e.getMessage(), "ERREUR", JOptionPane.ERROR_MESSAGE);
            }

        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, e.getMessage(), "ERREUR", JOptionPane.ERROR_MESSAGE);
        }
    }
}
