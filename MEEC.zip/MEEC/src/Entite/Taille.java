/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author cyril
 */
public class Taille {
    private String tailCode;
    private String tailLong;
    private String tailLarg;
    private String tailHaut;
    private final ArrayList<Taille> lesEnrg= new ArrayList<>();
    private static Connection laConnexion=
            ControleConnexion.getLaConnexionStatique();

    public String getTailCode() {
        return tailCode;
    }
    public String getTailLong() {
        return tailLong;
    }
    public String getTailLarg() {
        return tailLarg;
    }
    public String getTailHaut() {
        return tailHaut;
    }
    public ArrayList<Taille> getLesEnrg() {
        return lesEnrg;
    }
    
    public void setTailCode(String tailCode) {
        this.tailCode = tailCode;
    }
    public void setTailLong(String tailLong) {
        this.tailLong = tailLong;
    }
    public void setTailLarg(String tailLarg) {
        this.tailLarg = tailLarg;
    }
    public void setTailHaut(String tailHaut) {
        this.tailHaut = tailHaut;
    }
    
    public Taille (){
        lireRecup("","","","");
    }
    
    public Taille(String contLibelle)
    {
        String reqSQL = "SELECT * FROM taille JOIN conteneur USING (tailCode) JOIN typeconteneur USING (contType) WHERE typeLibel = '" + contLibelle + "';";
        
        lesEnrg.retainAll(lesEnrg);
        try {
            //permet d'alimenter le jeu d'enregistrement
            Statement state= laConnexion.createStatement();
            ResultSet rs=state.executeQuery(reqSQL);
                while (rs.next()){
                   String untailCode = rs.getString("tailCode");   
                   String untailLong = rs.getString("tailLong");
                   String untailLarg = rs.getString("tailLarg");
                   String untailHaut = rs.getString("tailHaut");
                   lesEnrg.add(new Taille(untailCode, untailLong, untailLarg, untailHaut));
                }
            }
         catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Problème rencontré : "
                    + ex.getMessage(),"Message", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public Taille(String tailCode, String tailLong, String tailLarg, String tailHaut){
        this.tailCode=tailCode;
        this.tailLong=tailLong;
        this.tailLarg=tailLarg;
        this.tailHaut=tailHaut;
        
        
        
    }
    
    private void lireRecup(String tailCode ,String tailLong, String tailLarg, String tailHaut ){
        //Lire les données de la BDD
        if (tailCode.equals("")){
            tailCode="%";
        } 
        if (tailLong.equals("")) {
            tailLong="%";
        } 
        if (tailLarg.equals("")){
            tailLarg="%";
        }
         if (tailHaut.equals("")){
            tailHaut="%";
        }
        
        
        String reqSQL="SELECT * FROM taille " ;
        //Vider tout les enregistrements
        lesEnrg.retainAll(lesEnrg);
        try {
            //permet d'alimenter le jeu d'enregistrement
            Statement state= laConnexion.createStatement();
            ResultSet rs=state.executeQuery(reqSQL);
                while (rs.next()){
                   String untailCode = rs.getString("tailCode");   
                   String untailLong = rs.getString("tailLong");
                   String untailLarg = rs.getString("tailLarg");
                   String untailHaut = rs.getString("tailHaut");
                   lesEnrg.add(new Taille(untailCode, untailLong, untailLarg, untailHaut));
                }
            }
         catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Problème rencontré : "
                    + ex.getMessage(),"Message", JOptionPane.ERROR_MESSAGE);
        }
    }
}
