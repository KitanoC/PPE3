/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author cyril
 */
public class Position {
    String numPosition;
    String numEmp;
    String numAllee;
    String numQuai;
    String etage;
    String numCont;

    private final ArrayList<Position> lesEnrg = new ArrayList <>();
    private static Connection laConnexion = ControleConnexion.getLaConnexionStatique();

 
    public String getNumpos() {
        return numPosition;
    }

    public void setNumpos(String numPosition) {
        this.numPosition = numPosition;
    }

    public String getNumemp() {
        return numEmp;
    }

    public void setNumemp(String numEmp) {
        this.numEmp = numEmp;
    }

    public String getNumallee() {
        return numAllee;
    }

    public void setNumallee(String numAllee) {
        this.numAllee = numAllee;
    }

    public String getNumquai() {
        return numQuai;
    }

    public void setNumquai(String numQuai) {
        this.numQuai = numQuai;
    }

    public String getEtage() {
        return etage;
    }

    public void setEtage(String etage) {
        this.etage = etage;
    }

    public String getNumcont() {
        return numCont;
    }

    public void setNumcont(String numCont) {
        this.numCont = numCont;
    }
    
    public ArrayList<Position> getLesEnrg(){
        return lesEnrg;
    }

    public Position(String numPosition, String numEmp, String numAllee, String numQuai, String etage, String numCont) {
        this.numPosition = numPosition;
        this.numEmp = numEmp;
        this.numAllee = numAllee;
        this.numQuai = numQuai;
        this.etage = etage;
        this.numCont = numCont;
    }

    //Constructeur Vide
    public Position() {
    }
    
    public Position(String numEmp, String numAllee, String numQuai, String etage, String numCont, boolean vide) 
    {
        lireRecup("", numEmp, numAllee, numQuai, etage, numCont, vide);
    }
    
    public Position(String numEmp, String numAllee, String numQuai, boolean vide)
    {
       lireRecup("", numEmp, numAllee, numQuai, "", "", vide);
    }

    public Position(String numEmp, String numAllee, String numQuai) 
    {
        lireRecup("", numEmp, numAllee,numQuai, "", "", false);
    }

    public Position(String numEmp, String numAllee, String numQuai, String etage, boolean vide) {
        lireRecup("", numEmp, numAllee,numQuai, etage, "", vide);
    }
    
     
    public Position(boolean vide) 
    {
        lireRecup("", "", "", "", "", "", vide);
    }
    
    public Position(String numPos, boolean vide) 
    {
        lireRecup("", "", "", "", "", numPos, vide);
    }
    
/*
    public Position(String numEmp, String numAllee, String numQuai, String etage, String numCont, boolean vide) {
        lireRecup("",numEmp, numAllee, numQuai, etage, numCont, vide);
    }

    public Position(String numEmp, String numAllee, String numQuai) {
        lireRecup("",numEmp, numAllee, numQuai,"","",false);
    }

    public Position(String numEmp, String numAllee, String numQuai, String etage, boolean vide) {
        lireRecup("",numEmp, numAllee, numQuai,etage,"",vide);
    }*/
    
     public void supprimer(String numEmp, String numAllee, String numQuai)
    {
        String requete = null;
        try 
        {
            requete = "DELETE FROM position WHERE numEmp = ? AND numAllee = ? AND numQuai = ?";
            PreparedStatement prepare = laConnexion.prepareStatement(requete);
            prepare.setString(1, numEmp);
            prepare.setString(2, numAllee);
            prepare.setString(3, numQuai);
            prepare.executeUpdate();
            prepare.close();
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Suppression non effectuée :" + ex.getMessage(), "ERREUR", JOptionPane.ERROR_MESSAGE);
        }
    }
    /*
    public void supprimer (String numPosition,String unNumAllee, String unNumQuai){
        String requete=null;
        try{
            requete="DELETE FROM emplacement WHERE numAllee=? and numQuai=? and numEmp=?";
            PreparedStatement prepare=laConnexion.prepareStatement(requete);
            prepare.setString(1,unNumAllee);
            prepare.setString(2,unNumQuai);
            prepare.setString(3,numPosition);
            prepare.executeUpdate();
            prepare.close();
            
            requete="DELETE FROM position WHERE numAllee=? and numQuai=? and numEmp=?";
            PreparedStatement prepare2=laConnexion.prepareStatement(requete);
            prepare2.setString(1,unNumAllee);
            prepare2.setString(2,unNumQuai);
            prepare2.setString(3,numPosition);
            prepare2.executeUpdate();
            prepare2.close();
        }catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "Suppression non effectuée :" + ex.getMessage(), "PROBLEME", JOptionPane.ERROR_MESSAGE);
        }
    }*/
    
    public void creer (String numEmp, String numAllee, String numQuai, String etage){
        String requete=null;
        String numPosition;
        try{
            //requete="INSERT INTO position (numPosition, numEmp, numAllee, numQuai, etage) VALUES (?,?,?,?,?)";
            requete = "INSERT INTO position VALUES (?, ?, ?, ?, ?, null)";
            PreparedStatement prepare;
            prepare = laConnexion.prepareStatement(requete);
            numPosition=numQuai+numAllee+numEmp+etage;
            prepare.setString(1, numPosition);
            prepare.setString(2, numQuai);
            prepare.setString(3, numAllee);
            prepare.setString(4, numEmp);
            prepare.setString(5, etage);
            prepare.execute();
            prepare.close();

        }catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "Ajout non effectuée :" + ex.getMessage(), "PROBLEME", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void miseAjour (String numPosition, String numCont){
       String requete=null;
       try{
           requete="UPDATE position SET numCont=? WHERE numPosition=?";
           PreparedStatement prepare= laConnexion.prepareStatement(requete);
           if (numCont.equals("")){
               prepare.setNull(1,0);
           }else{
               prepare.setString(1, numCont);
           }
           prepare.setString(2, numPosition);
           prepare.executeUpdate();
           prepare.close();
       }catch (SQLException ex){
           JOptionPane.showMessageDialog(null, "Mise a jour non effectuée :" + ex.getMessage(), "PROBLEME", JOptionPane.ERROR_MESSAGE);
       }
    }
    
    private void lireRecup(String numPosition, String numEmp, String numAllee, String numQuai,
            String etage, String numCont, boolean vide){
        if (numPosition.equals("")){
            numPosition="%";
        }
        if (numEmp.equals("")){
            numEmp="%";
        }
        if (numAllee.equals("")){
            numAllee="%";
        }
        if (numQuai.equals("")){
            numQuai="%";
        }
        if (!etage.equals("")){
            etage="and etage LIKE'" + etage + "'";
        }
        if (numCont.equals("")) {
            numCont="%";
        }
        String rqFin = " AND numCont IS NOT NULL";
        if(vide)
        {
            rqFin = " AND numCont IS NULL";
        }
        // Creation de la req
        String rqSQL="SELECT * FROM position WHERE numPosition LIKE '"
                + numPosition + "' AND numEmp LIKE '" + numEmp 
                + "' AND numAllee LIKE '" + numAllee +
                "' AND numQuai LIKE '" + numQuai + "' " + rqFin + " ORDER BY numQuai, numAllee,"
                + " numEmp, etage";
        // Vider les enregistrements 
        lesEnrg.retainAll(lesEnrg);
        
        
            Statement state;
        try {
            state = laConnexion.createStatement();
            ResultSet rs=state.executeQuery(rqSQL);
            while(rs.next()){
                String unIdQuai=rs.getString("numQuai");
                String unIdAllee=rs.getString("numAllee");
                String unEmplacement = rs.getString("numEmp");
                String unEtage = rs.getString("etage");
                String unNumCont =rs.getString("numCont");
                String unIdposition = rs.getString("numPosition");
                lesEnrg.add(new Position(unIdposition,unEmplacement,unIdAllee, unIdQuai, unEtage, unNumCont));
            }
            } catch (SQLException ex) {
            Logger.getLogger(Position.class.getName()).log(Level.SEVERE, null, ex);
        }
        
            
        }
  
}

