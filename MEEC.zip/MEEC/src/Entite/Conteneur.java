/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Flo
 */
public class Conteneur 
{
    private String contCode;
    private String contType;
    private String tailCode;
    private final ArrayList<Conteneur> lesEnrg = new ArrayList<>();
    private static Connection laConnexion = ControleConnexion.getLaConnexionStatique();

    public String getContCode() {
        return contCode;
    }

    public String getContType() {
        return contType;
    }

    public String getTailCode() {
        return tailCode;
    }

    public ArrayList<Conteneur> getLesEnrg() {
        return lesEnrg;
    }

    public void setContCode(String contCode) {
        this.contCode = contCode;
    }

    public void setContType(String contType) {
        this.contType = contType;
    }

    public void setTailCode(String tailCode) {
        this.tailCode = tailCode;
    }
    
    public Conteneur(String contCode, String contType, String tailCode) 
    {
        this.contCode = contCode;
        this.contType = contType;
        this.tailCode = tailCode;
    }
    
    public Conteneur() 
    {
        lireRecup();
    }
    
    private void lireRecup()
    {
        // CRUD
        // Create
        // Read
        // Update
        // Delete
        
        // Lire les données de la BDD
        
        /*String reqSQL = "SELECT * FROM conteneur";
        
        lesEnrg.retainAll(lesEnrg);  // Vider les enregistrements.
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            while(rs.next())
            {
                String leContCode = rs.getString("contCode");
                int leContType = rs.getInt("contType");
                int leTailCode = rs.getInt("tailCode");
                lesEnrg.add(new Conteneur(leContCode, leContType, leTailCode));
            }
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }*/
        
        if(contCode == "")
        {
            contCode = "%";
        }
        
        if(contType == "")
        {
            contType = "%";
        }
        
        if(tailCode == "")
        {
            tailCode = "%";
        }
        
        String reqSQL = "SELECT * FROM conteneur WHERE contCode LIKE " + contCode + " AND contType LIKE " + contType + " AND tailCode LIKE " + tailCode;
        
        lesEnrg.retainAll(lesEnrg);  // Vider les enregistrements.
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            while(rs.next())
            {
                String leContCode = rs.getString("contCode");
                String leContType = rs.getString("contType");
                String leTailCode = rs.getString("tailCode");
                lesEnrg.add(new Conteneur(leContCode, leContType, leTailCode));
            }
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
    }
        
}
