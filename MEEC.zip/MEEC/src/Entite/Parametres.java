/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

/**
 *
 * @author cyril
 */
public class Parametres {
    private String nomUtilisateur;
    private String motDePasse;
    private String serveurBD;
    private String driverSGBD;
    private String nomResponsable;
    private String mDPResponsable;

    public String getNomUtilisateur() {
        return nomUtilisateur;
    }

    public void setNomUtilisateur(String nomUtilisateur) {
        this.nomUtilisateur = nomUtilisateur;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public String getServeurBD() {
        return serveurBD;
    }

    public void setServeurBD(String serveurBD) {
        this.serveurBD = serveurBD;
    }

    public String getDriverSGBD() {
        return driverSGBD;
    }

    public void setDriverSGBD(String driverSGBD) {
        this.driverSGBD = driverSGBD;
    }

    public String getNomResponsable() {
        return nomResponsable;
    }

    public void setNomResponsable(String nomResponsable) {
        this.nomResponsable = nomResponsable;
    }

    public String getmDPResponsable() {
        return mDPResponsable;
    }

    public void setmDPResponsable(String mDPResponsable) {
        this.mDPResponsable = mDPResponsable;
    }

    public Parametres() {
        
        nomUtilisateur ="root";
        motDePasse="";
        driverSGBD="org.gjt.mm.mysql.Driver";
        serveurBD="jdbc:mysql://localhost/meec";
        nomResponsable="Gestion";
        mDPResponsable="azerty";
        
    }
    
    
}
