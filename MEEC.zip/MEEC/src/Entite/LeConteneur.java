/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JOptionPane;


/**
 *
 * @author Flo
 */
public class LeConteneur {
    
    public String numCont;
    public String numCli;
    public String dateA;
    public String contCode;
    public String codePosition;
    
    private final ArrayList<LeConteneur> lesEnrg = new ArrayList<>();
    private static Connection laConnexion = ControleConnexion.getLaConnexionStatique();


    // Get
    
    public String getNumCont() {
        return numCont;
    }

    public String getNumCli() {
        return numCli;
    }

    public String getDateA() {
        return dateA;
    }

    public String getContCode() {
        return contCode;
    }

    public String getCodePosition() {
        return codePosition;
    }
    
    // Set

    public void setNumCont(String numCont) {
        this.numCont = numCont;
    }

    public void setNumCli(String numCli) {
        this.numCli = numCli;
    }

    public void setDateA(String dateA) {
        this.dateA = dateA;
    }

    public void setContCode(String contCode) {
        this.contCode = contCode;
    }

    public void setCodePosition(String codePosition) {
        this.codePosition = codePosition;
    }
    
     public ArrayList<LeConteneur> getLesEnrg(){
        return lesEnrg;
    }
    
    public LeConteneur()
    {
        lireRecup("", "", "", "", "");
    }
    
    public LeConteneur(String numCont)
    {
        lireRecup(numCont, "", "", "", "");
    }
    
    
    
    public LeConteneur(String numCont, String numCli)
    {
        lireRecup(numCont, numCli, "", "", "");
    }
    
    public LeConteneur(String numCont, String numCli, String contCode)
    {
        lireRecup(numCont, numCli, contCode, "", "");
    }
    
   /* public LeConteneur(String numCont, String numCli, String dateA)
    {
        lireRecup(numCont, numCli, dateA, "", "");
    }
    */
    public LeConteneur(String numCont, String numCli, String dateA, String contCode)
    {
        lireRecup(numCont, numCli, dateA, contCode, "");
    }
    
    public LeConteneur(String leNumCont, String leNumCli, String laDateA, String leContCode, String leCodePosition)
    {
        this.numCont = leNumCont;
        this.numCli = leNumCli;
        this.dateA = laDateA;
        this.contCode = leContCode;
        this.codePosition = leCodePosition;
    }
   
    
     public boolean verifNumCont(String numSerie)
    {
        boolean verif = false;
        
        if(numSerie.length() != 11)
        {
            return false;
        }
        
        HashMap Ref = new HashMap();
        Ref.put('A', 10);
        Ref.put('B', 12);
        Ref.put('C', 13);
        Ref.put('D', 14);
        Ref.put('E', 15);
        Ref.put('F', 16);
        Ref.put('G', 17);
        Ref.put('H', 18);
        Ref.put('I', 19);
        Ref.put('J', 20);
        Ref.put('K', 21);
        Ref.put('L', 23);
        Ref.put('M', 24);
        Ref.put('N', 25);
        Ref.put('O', 26);
        Ref.put('P', 27);
        Ref.put('Q', 28);
        Ref.put('R', 29);
        Ref.put('S', 30);
        Ref.put('T', 31);
        Ref.put('U', 32);
        Ref.put('V', 34);
        Ref.put('W', 35);
        Ref.put('X', 36);
        Ref.put('Y', 37);
        Ref.put('Z', 38);
        
        int V1 = (int) Ref.get(numSerie.charAt(0));
        
        V1 += 2 * (int) Ref.get(numSerie.charAt(1));
        V1 += 4 * (int) Ref.get(numSerie.charAt(2));
        V1 += 8 * (int) Ref.get(numSerie.charAt(3));
        V1 += 16 * Integer.parseInt(numSerie.charAt(4)+"");
        V1 += 32 * Integer.parseInt(numSerie.charAt(5)+"");
        V1 += 64 * Integer.parseInt(numSerie.charAt(6)+"");
        V1 += 128 * Integer.parseInt(numSerie.charAt(7)+"");
        V1 += 256 * Integer.parseInt(numSerie.charAt(8)+"");
        V1 += 512 * Integer.parseInt(numSerie.charAt(9)+"");
        
        int V2 = V1 / 11;
        V2 = V2 * 11;
        V2 = V1 - V2;
        
        if(V2 == Integer.parseInt(numSerie.charAt(10)+""))
        {
            verif = true;
        }
        else
        {
            verif = false;
        }
        
        return verif;
    }
    
    public void creer(String numCont, String numCli, String dateA, String contCode, String codePosition)
    {
        String requete = null;
        
        
        
        try{
            
            if(numCli == "" && dateA == "")
            {
                requete = "INSERT INTO leconteneur VALUES (?, NULL, NULL, ?, ?)";
                PreparedStatement prepare;
                prepare = laConnexion.prepareStatement(requete);

                prepare.setString(1, numCont);
                prepare.setString(2, contCode);
                prepare.setString(3, codePosition);
                prepare.execute();
                prepare.close();
            }
            else if(numCli == "")
            {
                requete = "INSERT INTO leconteneur VALUES (?, NULL, ?, ?, ?)";
                PreparedStatement prepare;
                prepare = laConnexion.prepareStatement(requete);

                prepare.setString(1, numCont);
                prepare.setString(2, dateA);
                prepare.setString(3, contCode);
                prepare.setString(4, codePosition);
                prepare.execute();
                prepare.close();
            }
            else if(dateA == "")
            {
                requete = "INSERT INTO leconteneur VALUES (?, ?, NULL, ?, ?)";
                PreparedStatement prepare;
                prepare = laConnexion.prepareStatement(requete);

                prepare.setString(1, numCont);
                prepare.setString(2, numCli);
                prepare.setString(3, contCode);
                prepare.setString(4, codePosition);
                prepare.execute();
                prepare.close();
            }
            else
            {
                requete = "INSERT INTO leconteneur VALUES (?, NULL, NULL, ?, ?)";
                PreparedStatement prepare;
                prepare = laConnexion.prepareStatement(requete);

                prepare.setString(1, numCont);
                prepare.setString(2, numCli);
                prepare.setString(3, dateA);
                prepare.setString(4, contCode);
                prepare.setString(5, codePosition);
                prepare.execute();
                prepare.close();
            }            
            
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Ajout non effectué :" + ex.getMessage(), "ERREUR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void modifier(String numCont, String numCli)
    {
        String requete = "UPDATE leconteneur SET numCli =";
        
        if(numCli.equals(""))
        {
            requete = requete + "NULL ";
        }else{
        
        requete=requete + "'"+numCli+"' ";
        }

        try{
            requete = requete +"WHERE numCont = ? ";
            PreparedStatement prepare;
            prepare = laConnexion.prepareStatement(requete);
            
            prepare.setString(1, numCont);
            prepare.execute();
            prepare.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Ajout non effectué :" + ex.getMessage(), "ERREUR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void supprimer(String numCont)
    {
        String requete = null;
        
        try{
            requete = "DELETE FROM leconteneur WHERE numCont = ? ";
            PreparedStatement prepare;
            prepare = laConnexion.prepareStatement(requete);
            
            prepare.setString(1, numCont);
            
            prepare.execute();
            prepare.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Ajout non effectué :" + ex.getMessage(), "ERREUR", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    private void lireRecup(String numCont, String numCli, String dateA, String contCode, String codePosition)
    {
        
        String reqSQL = "SELECT * FROM leconteneur";
        
        int args = 0;
                
        if(!numCont.equals("") || !numCli.equals("") || !dateA.equals("") || !contCode.equals("") || !codePosition.equals(""))
        {
            reqSQL = reqSQL + " WHERE ";
        }
        
        if(!numCont.equals(""))
        {
            if(args == 0)
            {
                 args++;
            }
            else
            {
                reqSQL = reqSQL + "AND";
            }
            
            reqSQL = reqSQL + " numCont LIKE '" + numCont + "'";
            
        }
        if(!numCli.equals(""))
        {
            if(args == 0)
            {
                 args++;
            }
            else
            {
                reqSQL = reqSQL + "AND";
            }
            
            reqSQL = reqSQL + " numCli LIKE '" + numCli + "'";
        }
        if(!dateA.equals(""))
        {
            if(args == 0)
            {
                 args++;
            }
            else
            {
                reqSQL = reqSQL + "AND";
            }
            
            reqSQL = reqSQL + " dateA LIKE '" + dateA + "'";
        }
        if(!contCode.equals(""))
        {
            if(args == 0)
            {
                 args++;
            }
            else
            {
                reqSQL = reqSQL + "AND";
            }
            
            reqSQL = reqSQL + " contCode LIKE '" + contCode + "'";
        }
        if(!codePosition.equals(""))
        {
            if(args == 0)
            {
                 args++;
            }
            else
            {
                reqSQL = reqSQL + "AND";
            }
            
            reqSQL = reqSQL + " contCode LIKE '" + contCode + "'";
        }
        
        //String reqSQL = "SELECT * FROM leconteneur WHERE numCont LIKE '" + numCont + "' AND numCli LIKE '" + numCli + "' AND dateA LIKE '" + dateA + "' AND contCode LIKE '" + contCode + "' AND codePosition LIKE '" + codePosition + "'";
        
        System.out.println(reqSQL);
        
        lesEnrg.retainAll(lesEnrg);  // Vider les enregistrements.
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            while(rs.next())
            {
                String leNumCont = rs.getString("numCont");
                String leNumCli = rs.getString("numCli");
                String laDateA = rs.getString("dateA");
                String leContCode = rs.getString("contCode");
                String leCodePosition = rs.getString("codePosition");
                lesEnrg.add(new LeConteneur(leNumCont, leNumCli, laDateA, leContCode, leCodePosition));
            }
            System.out.println("Nombre d'enregistrements : " + lesEnrg.size());
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /*
    
    public String numCont;
    public String numCli;
    public String dateA;
    public String contCode;
    public String codePosition;
    
    */
    
      /*  private void lireRecup(String numCont, String numCli, String dateA, String contCode, String codePosition)
    {
        String reqSQL = "SELECT * FROM leconteneur WHERE ";
        
        if(numCont == "")
        {
            numCont = "%";
        }
        reqSQL = reqSQL + " contCode LIKE '" + numCont + "' "; 
        if(numCli != "")
        {
           reqSQL = reqSQL + " AND numCli = '" + numCli + "'" ;
        }
        
        if(codePosition == "")
        {
            codePosition = "%";
        }
        
        if (dateA == "") {
            dateA = "%";
        }
        
        if (contCode == "" ) {
            contCode = "%";
        }
        
        reqSQL = reqSQL + " AND codePosition LIKE '" + codePosition + "'";
        
        //System.out.println(reqSQL);
        
        lesEnrg.retainAll(lesEnrg);  // Vider les enregistrements.
        try 
        {
            Statement state = laConnexion.createStatement();
            ResultSet rs = state.executeQuery(reqSQL);
            
            while(rs.next())
            {
                String leNumCont = rs.getString("numCont");
                String leNumCli = rs.getString("numCli");
                String laDateA = rs.getString("dateA");
                String leContCode = rs.getString("contCode");
                String leCodePosition = rs.getString("codePosition");
                lesEnrg.add(new LeConteneur(leNumCont, leNumCli, laDateA, leContCode, leCodePosition));
            }
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Problème rencontré : " + ex.getMessage(), "MESSAGE", JOptionPane.ERROR_MESSAGE);
        }
    }
    */
}
