/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author cyril
 */
public class Quai {
    private String NumQuai;
    private final ArrayList<Quai> lesEnrg= new ArrayList<>();
    
    private static Connection laConnexion= 
            ControleConnexion.getLaConnexionStatique();

    public String getNumQuai() {
        return NumQuai;
    }

    public ArrayList<Quai> getLesEnrg() {
        return lesEnrg;
    }

    public void setNumQuai(String NumQuai) {
        this.NumQuai = NumQuai;
    }
    
    //Creer constructeur qui permet de construire le quai quand on lui passe un 
    //numero
    
    public Quai(String numQuai){
        this.NumQuai = numQuai;
    }

    public Quai() {
        lireRecup("");
    }
    
    
    
    //Interroge la BDD 
    private void lireRecup(String unNumQuai){
        //Lire les données de la BDD
        if (unNumQuai.equals("")){
            unNumQuai="%";
        }
        String reqSQL="SELECT * FROM quai WHERE numquai LIKE '" + unNumQuai +"'";
        //Vider tout les enregistrements
        lesEnrg.retainAll(lesEnrg);
        try {
            //permet d'alimenter le jeu d'enregistrement
            Statement state= laConnexion.createStatement();
            ResultSet rs=state.executeQuery(reqSQL);
                while (rs.next()){
                   String leNumQuai = rs.getString("numquai");
                   lesEnrg.add(new Quai(leNumQuai));
                }
            }
         catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Problème rencontré : "
                    + ex.getMessage(),"Message", JOptionPane.ERROR_MESSAGE);
        }
        }
    public boolean creer(String unNumQuai){
            boolean bcreer=false;
            String reqSQL="SELECT count(*) as nb FROM quai WHERE numquai='"
                    +unNumQuai + "'";
            try{
                Statement state = laConnexion.createStatement();
                ResultSet rs=state.executeQuery(reqSQL);
                rs.next();
                    if(rs.getInt("nb")==0){
                    // Le ? indique tout les endroits que l'on remplira plus tard
                        String reqSQLA="INSERT INTO quai VALUES(?)"; 
                        PreparedStatement prepare= laConnexion.prepareStatement(reqSQLA);
                        prepare.setString(1,unNumQuai);
                        //Execute le prepare
                        prepare.execute();
                        prepare.close();
                        bcreer=true;
                    }else{
                         JOptionPane.showMessageDialog(null,"Le numero de quai existe déjà "
                    ,"Erreur", JOptionPane.ERROR_MESSAGE);
                    }
                }catch (SQLException ex){
                 JOptionPane.showMessageDialog(null,"Problème rencontré : "
                    + ex.getMessage(),"Message", JOptionPane.ERROR_MESSAGE);
            }
            return bcreer;
    }
    
    public boolean supprimer(String unNumQuai){
        boolean bsupp=false;
        String reqSQL="SELECT count(*) as nb FROM allee WHERE numquai='"+unNumQuai+"'";
        try {
            Statement state= laConnexion.createStatement();
            ResultSet rs=state.executeQuery(reqSQL);
            rs.next();
            if(rs.getInt("nb")==0){
                String reqSQLD="DELETE FROM quai WHERE numquai=?"; 
                        PreparedStatement prepare= laConnexion.prepareStatement(reqSQLD);
                        prepare.setString(1,unNumQuai);
                        prepare.execute();
                        prepare.close();
                        bsupp=true;
                        }else{
                            JOptionPane.showMessageDialog(null,"Le quai comporte"
                                    + " encore des allées","Erreur",
                                    JOptionPane.ERROR_MESSAGE);
                        }
            } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Problème rencontré : "
                    + ex.getMessage(),"Message", JOptionPane.ERROR_MESSAGE);
        }
        
        return bsupp;
    }
    
    //public 
}
    
    
    
    
    
