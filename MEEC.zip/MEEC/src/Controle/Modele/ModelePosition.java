/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle.Modele;

import Entite.Position;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author cyril
 */

public class ModelePosition extends AbstractTableModel{
    Position instanceConteneurPhysique;
    private ArrayList<Position> lesDonnees;
    private final String[] lesTitres={"Etage","N° Conteneur"};

public ModelePosition(){
    this.instanceConteneurPhysique = new Position();
    this.lesDonnees = instanceConteneurPhysique.getLesEnrg();
}
public ModelePosition (String Quai, String Allee, String Emplacement,boolean vide){
    this.instanceConteneurPhysique = new Position (Emplacement, Allee, Quai,vide);
    this.lesDonnees = instanceConteneurPhysique.getLesEnrg();
}

    @Override
    public int getRowCount() {
        return lesDonnees.size(); 
    }

    @Override
    public int getColumnCount() {
        return lesTitres.length;
    }

    @Override
    public String getColumnName(int columnIndex){
        return lesTitres[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0 : return lesDonnees.get(rowIndex).getEtage();
            case 1 : return lesDonnees.get(rowIndex).getNumcont();
            default : return null;
        }
    }
}
