/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle.Modele;

import Entite.LeConteneur;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Flo
 */
public class ModeleChargerCont extends AbstractTableModel
{
    LeConteneur instanceConteneurPhysique;
    private ArrayList<LeConteneur> lesDonnees;
    
    private final String[] lesTitres = {"N° conteneur", "N° client"};
    
    public ModeleChargerCont()
    {
        this.instanceConteneurPhysique = new LeConteneur();
        this.lesDonnees = instanceConteneurPhysique.getLesEnrg();
    }
    
    @Override
    public int getRowCount() {
        return lesDonnees.size();
    }

    @Override
    public int getColumnCount() {
        return lesTitres.length;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return lesTitres[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex)
        {
            case 0 : return lesDonnees.get(rowIndex).getNumCont();
            case 1 : return lesDonnees.get(rowIndex).getNumCli();
            default : return null;
        }
    }

    
    
    @Override
    public boolean isCellEditable(int row, int col) {
        return (col == 2); 
    }
    
    /*@Override
    public Class<?> getColumnClass(int columnIndex) {
        return this.getValueAt(0, columnIndex).getClass();
    }*/
}
