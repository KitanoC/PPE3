/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle.Modele;

import Entite.Position;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Flo
 */
public class ModeleSuppCont extends AbstractTableModel {
    Position instanceConteneurPhysique;
    private ArrayList<Position> lesDonnees;
    private final String[] lesTitres = {"N° conteneur", "Quai", "Allée", "Emplacement", "Position"};
    
    public ModeleSuppCont(String Quai, String Allee, String Emplacement, String numCont, boolean vide)
    {
        this.instanceConteneurPhysique = new Position(Emplacement, Allee, Quai, "",  vide);
        this.lesDonnees = instanceConteneurPhysique.getLesEnrg();
    }
    
    /*public ModeleSuppCont()
    {
        this.instanceConteneurPhysique = new Position();
        this.lesDonnees = instanceConteneurPhysique.getLesEnrg();
    }*/
    
    @Override
    public int getRowCount() {
        return lesDonnees.size();
    }

    @Override
    public int getColumnCount() {
        return lesTitres.length;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return lesTitres[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex)
        {
            case 0 : return lesDonnees.get(rowIndex).getNumcont();
            case 1 : return lesDonnees.get(rowIndex).getNumquai();
            case 2 : return lesDonnees.get(rowIndex).getNumallee();
            case 3 : return lesDonnees.get(rowIndex).getNumemp();
            case 4 : return lesDonnees.get(rowIndex).getEtage();
            default : return null;
        }
    }
    
}
