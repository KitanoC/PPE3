/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle.Modele;

import Entite.LeConteneur;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Flo
 */
public class ModeleModifCont extends AbstractTableModel {
    LeConteneur instanceConteneurPhysique;
    private ArrayList<LeConteneur> lesDonnees;
    private final String[] lesTitres = {"N° conteneur", "Client", "Position"};
    
    public ModeleModifCont(String numCont, String numCli, String codePosition)
    {
        this.instanceConteneurPhysique = new LeConteneur(numCont, numCli, codePosition);
        this.lesDonnees = instanceConteneurPhysique.getLesEnrg();
    }
    
    /*public ModeleSuppCont()
    {
        this.instanceConteneurPhysique = new Position();
        this.lesDonnees = instanceConteneurPhysique.getLesEnrg();
    }*/
    
    @Override
    public int getRowCount() {
        return lesDonnees.size();
    }

    @Override
    public int getColumnCount() {
        return lesTitres.length;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return lesTitres[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex)
        {
            case 0 : return lesDonnees.get(rowIndex).getNumCont();
            case 1 : return lesDonnees.get(rowIndex).getNumCli();
            case 2 : return lesDonnees.get(rowIndex).getCodePosition();
            default : return null;
        }
    }
    
}
