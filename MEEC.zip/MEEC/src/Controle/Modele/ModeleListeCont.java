/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle.modele;

import Entite.LeConteneur;
import java.util.ArrayList;
import javax.swing.AbstractListModel;

/**
 *
 * @author Flo
 */
public class ModeleListeCont extends AbstractListModel {
    
    LeConteneur instanceConteneurPhysique;
    private ArrayList<LeConteneur> lesDonnees;
    
    public ModeleListeCont()
    {
        this.instanceConteneurPhysique = new LeConteneur();
        
        this.lesDonnees = instanceConteneurPhysique.getLesEnrg();
        
        System.out.println("Nombre d'éléments : " + this.getSize());
    }
    
    @Override
    public int getSize()
    {
        return lesDonnees.size();
    }
    
    @Override
    public Object getElementAt(int index)
    {
        return lesDonnees.get(index).numCont;
    }
    
}
