/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle.Modele;

import Entite.LeConteneur;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Flo
 */
public class ModeleListeContACharger extends AbstractTableModel 
{
    private ArrayList<String> lesDonnees = new ArrayList<>();
    
    private final String[] lesTitres = {"N° conteneur"};
    
    public ModeleListeContACharger(ArrayList<String> liste)
    {
        int i = 0;
        if(liste.size() != 0)
        {
            lesDonnees.clear();   
            for(i = 0; i < liste.size(); i++)
            {
                lesDonnees.add(liste.get(i));
            }
        }
        
    }
    
    public ModeleListeContACharger()
    {
        
        
    }
    
    @Override
    public int getRowCount() {
        return lesDonnees.size();
    }

    @Override
    public int getColumnCount() {
        return lesTitres.length;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return lesTitres[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex)
        {
            case 0 : return lesDonnees.get(rowIndex);
            default : return null;
        }
    }
}
