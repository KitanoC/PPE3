/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle.Connexion;

import Entite.Parametres;
import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



/**
 *
 * @author cyril
 */
public abstract class ControleConnexion {
    
    static Parametres lesParametres;
    static boolean etatConnexion;
    static Connection laConnexionStatique;
    
    static {
    
        boolean ok=true;
        lesParametres=new Parametres() ;
        try {
            Class.forName(lesParametres.getDriverSGBD());
            etatConnexion=true;
        } catch (ClassNotFoundException ex) {
           JOptionPane.showMessageDialog(null,"Classe non trouvée"
                                +" pour le chargement du pilote JDBC",
                                "ALERTE",JOptionPane.ERROR_MESSAGE);
            ok=false;
            etatConnexion=false;
        }
        // Etablir la connexion
        
        if (ok){
            //Recupere les parametres
            String urlBD=lesParametres.getServeurBD();
            String nomUtilisateur=lesParametres.getNomUtilisateur();
            String mDP=lesParametres.getMotDePasse();
            
            
            try {
                //Creation de la connexion
                laConnexionStatique=(Connection) DriverManager.getConnection(urlBD, nomUtilisateur, mDP);
                etatConnexion=true;
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null,"Impossible de se connecter "
                        +"a la base de données","ALERTE",JOptionPane.ERROR_MESSAGE);
                etatConnexion=false;
            }
            
            
        }
        
        
        
    }

    public static Parametres getLesParametres() {
        return lesParametres;
    }

    public static boolean isEtatConnexion() {
        return etatConnexion;
    }

    public static Connection getLaConnexionStatique() {
        return laConnexionStatique;
    }
    
    public static boolean control(String nom, String mdp){
        boolean verification;
        // verif user et mdp
        if(nom.equals(lesParametres.getNomResponsable())&& 
                mdp.equals(lesParametres.getmDPResponsable())){
            //verif connection
            verification = etatConnexion;
        }else{
            JOptionPane.showMessageDialog(null,"Erreur de saisie", 
                    "Erreur", JOptionPane.ERROR_MESSAGE);
            verification=false;
        }
        return verification;
    }
    public static void fermetureSession() throws SQLException{
        laConnexionStatique.close();
    }
}
